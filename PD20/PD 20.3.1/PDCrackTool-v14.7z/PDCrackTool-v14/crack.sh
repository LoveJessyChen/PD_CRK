#!/bin/bash

while [[ $# -gt 0 ]]; do
  case $1 in
    -l|--lang)
      export SCRIPT_LANGUAGE="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done

[ -f "scripts/utils.sh" ] && source "scripts/utils.sh" || { 
  printf "\033[0;31m[Error] scripts/utils.sh not found!${NOCOLOR}\n"
  exit 1
}

[ -f "scripts/menu.sh" ] && source "scripts/menu.sh" || {
  printf "\033[0;31m[Error] scripts/menu.sh not found!${NOCOLOR}\n"
      exit 1
}

check_root
main_menu