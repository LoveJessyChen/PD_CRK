#!/bin/bash

[ -f "scripts/utils.sh" ] && source "scripts/utils.sh" || {
  echo "Error: utils.sh not found"
  exit 1
}

[ -f "scripts/menu.sh" ] && source "scripts/menu.sh" || {
  echo "Error: menu.sh not found"
  exit 1
}

crack_toolbox() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"
  
  clear
  print_info "开始破解 Parallels Toolbox..."

  local TOOLBOX_DIR="/Applications/Parallels Toolbox.app"
  local DYLIB_NAME="CoreInject.dylib"
  local LICENSE_SERVICES="${TOOLBOX_DIR}/Contents/Frameworks/LicenseServices.framework/Versions/A/LicenseServices"
  local download_url="https://download.parallels.com/toolbox/v7/7.0.0-5272/ParallelsToolbox-7.0.0-5272.dmg"
  local download_filename="ParallelsToolbox-7.0.0-5272.dmg"
  
  if [ ! -d "$TOOLBOX_DIR" ]; then
    ask_download "$download_url" "$download_filename" "Parallels Toolbox" || exit 1
  fi
  
  [ ! -f "./$DYLIB_NAME" ] && { print_error "核心注入文件 $DYLIB_NAME 不存在，请确保文件在当前目录"; exit 1; }
  [ ! -f "./insert_dylib" ] && { print_error "insert_dylib 工具不存在，请确保文件在当前目录"; exit 1; }
  [ ! -f "./GenShineImpactStarter" ] && { print_error "GenShineImpactStarter 工具不存在，请确保文件在当前目录"; exit 1; }
  [ ! -f "$LICENSE_SERVICES" ] && { print_error "找不到 LicenseServices 文件"; exit 1; }

  print_info "确保你的版本是: ${download_url}"

  pkill -f "Parallels Toolbox" &>/dev/null
  print_info "${MSG_STOPPING_PT}"

  run_cmd "xattr -cr \"./$DYLIB_NAME\" ./*" "${MSG_CLEARING_ATTR}" "${MSG_CLEARING_ATTR}"
  run_cmd "chmod +x ./GenShineImpactStarter" "${MSG_CLEARING_ATTR} GenShineImpactStarter" "${MSG_SET_EXEC_PERM}"

  print_info "${MSG_COPYING_CORE}"
  run_cmd "sudo cp \"./$DYLIB_NAME\" \"${TOOLBOX_DIR}/Contents/Frameworks/$DYLIB_NAME\"" \
    "${MSG_CLEARING_ATTR} $DYLIB_NAME 到 ${TOOLBOX_DIR}/Contents/Frameworks/" "${MSG_COPYING_CORE}"

  print_info "${MSG_INJECT_LICENSE}"
  
  if [ ! -f "${LICENSE_SERVICES}_backup" ]; then
    run_cmd "cp \"$LICENSE_SERVICES\" \"${LICENSE_SERVICES}_backup\"" "${MSG_CLEARING_ATTR} LicenseServices 备份" "${MSG_BACKUP_CREATED}"
  fi
  
  run_cmd "cp \"${LICENSE_SERVICES}_backup\" \"$LICENSE_SERVICES\"" "${MSG_CLEARING_ATTR} LicenseServices" "${MSG_RESTORING_BACKUP}"
  run_cmd "\"./insert_dylib\" \"@rpath/$DYLIB_NAME\" \"$LICENSE_SERVICES\" \"${LICENSE_SERVICES}_tmp\"" "${MSG_CLEARING_ATTR} LicenseServices" "${MSG_INJECTING}"
  run_cmd "mv \"${LICENSE_SERVICES}_tmp\" \"$LICENSE_SERVICES\"" "${MSG_CLEARING_ATTR} LicenseServices" "${MSG_RESTORING_BACKUP}"
  run_cmd "codesign -f -s - --timestamp=none --all-architectures \"$LICENSE_SERVICES\"" "${MSG_CLEARING_ATTR} LicenseServices" "${MSG_SIGNING_LICENSE}"
  run_cmd "codesign -f -s - --timestamp=none --all-architectures \"${TOOLBOX_DIR}/Contents/Frameworks/LicenseServices.framework\"" \
    "${MSG_CLEARING_ATTR} LicenseServices 框架" "${MSG_SIGNING_FRAMEWORK}"

  local tbox="${TOOLBOX_DIR}/Contents/MacOS/Parallels Toolbox"
  print_info "${MSG_SIGNING_MAIN}"
  run_cmd "codesign -f -s - --timestamp=none --all-architectures \"$tbox\"" "${MSG_CLEARING_ATTR} 主程序" "${MSG_SIGNING_MAIN}"

  print_info "${MSG_INJECT_SIGN_APPS}"
  process_applications
  
  fix_special_apps
  
  print_info "${MSG_FINAL_SIGNING}"
  run_cmd "codesign -f -s - --timestamp=none --deep --all-architectures \"$TOOLBOX_DIR\"" \
    "${MSG_CLEARING_ATTR} 最终签名 Parallels Toolbox" "${MSG_FINAL_SIGNING}"

  print_info "${MSG_PT_CRACK_COMPLETE}"
  
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} ${MSG_EXIT}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  
  read -p "${MSG_OPTION} [1-2]: " choice
  case "$choice" in
    1)
      main_menu
      ;;
    *)
      exit 0
      ;;
  esac
}

process_applications() {
  local TOOLBOX_DIR="/Applications/Parallels Toolbox.app"
  local DYLIB_NAME="CoreInject.dylib"
  
  find "$TOOLBOX_DIR/Contents/Applications" -name "*.app" -type d | while read app; do
    local app_name=$(basename "$app")
    print_info "${MSG_PROCESSING_APP}: $app_name"
    
    local app_binary="$app/Contents/MacOS/$app_name"
    if [ ! -f "$app_binary" ]; then
      app_binary=$(find "$app/Contents/MacOS" -type f -perm +111 | head -1)
      if [ ! -f "$app_binary" ]; then
        print_error "${MSG_APP_BINARY_NOT_FOUND}: $app_name"
        continue
      fi
    fi
    
    print_info "${MSG_INJECTING_APP}: $app_name"
    if [ ! -f "${app_binary}_backup" ]; then
      run_cmd "cp \"$app_binary\" \"${app_binary}_backup\"" "${MSG_CLEARING_ATTR} 备份: ${app_binary}" "${MSG_BACKUP_CREATED}"
    fi
    
    run_cmd "cp \"${app_binary}_backup\" \"$app_binary\"" "${MSG_CLEARING_ATTR} 恢复备份: ${app_binary}" "${MSG_RESTORING_BACKUP}"
    run_cmd "\"./insert_dylib\" \"@rpath/$DYLIB_NAME\" \"$app_binary\" \"${app_binary}_tmp\"" \
      "${MSG_CLEARING_ATTR} 注入动态库到: ${app_binary}" "${MSG_INJECTING}"
    run_cmd "mv \"${app_binary}_tmp\" \"$app_binary\"" "${MSG_CLEARING_ATTR} 替换: ${app_binary}" "${MSG_REPLACING}"
    run_cmd "codesign -f -s - --timestamp=none --all-architectures \"$app_binary\"" \
      "${MSG_CLEARING_ATTR} 签名: ${app_binary}" "${MSG_SIGNING_BINARY}"
    run_cmd "codesign -f -s - --timestamp=none --deep --all-architectures \"$app\"" \
      "${MSG_CLEARING_ATTR} 签名应用: ${app_name}" "${MSG_SIGNING_APP}"
  done
}

fix_special_apps() {
  local TOOLBOX_DIR="/Applications/Parallels Toolbox.app"
  local DYLIB_NAME="CoreInject.dylib"
  
  fix_helper_app "${MSG_UNINSTALL_APPS}" \
    "${TOOLBOX_DIR}/Contents/Applications/Uninstall Apps.app/Contents/Library/LaunchServices/com.parallels.toolbox.UninstallAppsHelper" \
    "${TOOLBOX_DIR}/Contents/Applications/Uninstall Apps.app/Contents/Info.plist" \
    "com.parallels.toolbox.UninstallAppsHelper"

  fix_helper_app "${MSG_ENERGY_SAVER}" \
    "${TOOLBOX_DIR}/Contents/Applications/Energy Saver.app/Contents/Library/LaunchServices/com.parallels.toolbox.EnergySaverHelper" \
    "${TOOLBOX_DIR}/Contents/Applications/Energy Saver.app/Contents/Info.plist" \
    "com.parallels.toolbox.EnergySaverHelper"

  fix_helper_app "${MSG_CLEAN_DRIVE}" \
    "${TOOLBOX_DIR}/Contents/Applications/Clean Drive.app/Contents/Library/LaunchServices/com.parallels.toolbox.CleanDriveHelper" \
    "${TOOLBOX_DIR}/Contents/Applications/Clean Drive.app/Contents/Info.plist" \
    "com.parallels.toolbox.CleanDriveHelper"
}

fix_helper_app() {
  local app_name="$1"
  local helper_path="$2"
  local plist_path="$3"
  local identifier="$4"
  
  print_info "${MSG_FIXING_HELPER}: $app_name"
  
  if [ ! -f "$helper_path" ]; then
    print_error "${MSG_HELPER_NOT_FOUND}: $app_name"
    return 0
  fi
  
  run_cmd "./GenShineImpactStarter \"$helper_path\"" "${MSG_INIT_HELPER}: $app_name" "${MSG_INIT_HELPER}"
  run_cmd "cp \"$helper_path\" \"${helper_path}_fix\"" "${MSG_CLEARING_ATTR} 辅助程序备份: $helper_path" "${MSG_BACKUP_CREATED}"
  run_cmd "\"./insert_dylib\" \"@rpath/$DYLIB_NAME\" \"${helper_path}_fix\" \"$helper_path\"" \
    "${MSG_CLEARING_ATTR} 注入动态库到辅助程序: $helper_path" "${MSG_INJECTING}"
  
  run_cmd "\"/usr/libexec/PlistBuddy\" \"-c\" \"Set :SMPrivilegedExecutables:$identifier 'identifier \\\"$identifier\\\"'\" \"$plist_path\"" \
    "${MSG_CLEARING_ATTR} 修改权限配置" "${MSG_MODIFY_PLIST}"
  
  run_cmd "codesign -f -s - --timestamp=none --all-architectures \"$helper_path\"" "${MSG_CLEARING_ATTR} 签名辅助程序: $helper_path" "${MSG_SIGNING_HELPER}"
  local app_path="${plist_path%/Contents/Info.plist}"
  run_cmd "codesign -f -s - --timestamp=none --all-architectures \"$app_path\"" \
    "${MSG_CLEARING_ATTR} 签名应用程序: $app_path" "${MSG_SIGNING_HELPER}"
  
  print_info "${MSG_PERMISSION_FIX_DONE}: $app_name"
}