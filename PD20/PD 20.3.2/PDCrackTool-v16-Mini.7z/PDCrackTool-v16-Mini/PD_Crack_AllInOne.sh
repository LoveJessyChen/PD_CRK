#!/bin/bash

COLOR_INFO='\e[0;34m'
COLOR_ERR='\e[0;35m'
COLOR_VERSION='\e[0;36m'
COLOR_TITLE='\e[0;33m'
COLOR_SUCCESS='\e[0;32m'
NOCOLOR='\e[0m'
PDFM_VER="20.3.2-55975"

printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
printf "${COLOR_VERSION}Developer: QiuChenly / 秋城落叶${NOCOLOR}\n"
printf "${COLOR_VERSION}Telegram: https://t.me/qiuchenlymac${NOCOLOR}\n"
printf "${COLOR_VERSION}TG聊天频道: https://t.me/+VvqTr-2EFaZhYzA1${NOCOLOR}\n"
printf "${COLOR_VERSION}这是PD官方为华为专门开发的全链路国产自研 HarmonyOS : 鸿蒙星河版 虚拟机, 我看再有人黑华为试试😡!${NOCOLOR}\n"
printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

printf "${COLOR_INFO}[*] 当前推荐安装的版本是: https://download.parallels.com/desktop/v20/${PDFM_VER}/ParallelsDesktop-${PDFM_VER}.dmg${NOCOLOR}\n"

ParaHome='/Applications/Parallels Desktop.app'
DYLIB="CoreInject.dylib"

[ ! -f "./$DYLIB" ] && {
    printf "${COLOR_ERR}[x] 找不到 $DYLIB 文件${NOCOLOR}\n"
    exit 1
}
[ ! -f "./insert_dylib" ] && {
    printf "${COLOR_ERR}[x] 找不到 insert_dylib 工具${NOCOLOR}\n"
    exit 1
}
[ ! -d "$ParaHome" ] && {
    printf "${COLOR_ERR}[x] 找不到 Parallels Desktop 应用${NOCOLOR}\n"
    exit 1
}

if pgrep -x "prl_disp_service" &>/dev/null; then
    printf "${COLOR_INFO}[*] 正在停止 Parallels Desktop 主程序...${NOCOLOR}\n"
    pkill -9 prl_client_app &>/dev/null
    "${ParaHome}/Contents/MacOS/Parallels Service" service_stop &>/dev/null
    sleep 1
    launchctl stop /Library/LaunchDaemons/com.parallels.desktop.launchdaemon.plist &>/dev/null
    sleep 1
    pkill -9 prl_disp_service &>/dev/null
    sleep 1
    rm -f "/var/run/prl_*"
fi

xattr -cr "./$DYLIB" ./* &>/dev/null

sudo codesign -f -s - --timestamp=none --all-architectures "./$DYLIB"
sudo cp "./$DYLIB" "${ParaHome}/Contents/Frameworks/$DYLIB"

chmod +x ./insert_dylib

patch_file() {
    local file="$1"
    printf "${COLOR_INFO}[*] 处理文件: $(basename "$file")${NOCOLOR}\n"

    [ ! -f "${file}_backup" ] && cp "$file" "${file}_backup"
    cp "${file}_backup" "$file"

    ./insert_dylib "@rpath/$DYLIB" "${file}_backup" "$file" &>/dev/null
    sudo codesign -f -s - --timestamp=none --all-architectures --entitlements './VM.entitlements' "$file"
}

patch_file "$ParaHome/Contents/MacOS/Parallels Service.app/Contents/MacOS/prl_disp_service"
patch_file "$ParaHome/Contents/MacOS/Parallels VM.app/Contents/MacOS/prl_vm_app"
patch_file "$ParaHome/Contents/MacOS/prl_client_app"

license_file="/Library/Preferences/Parallels/licenses.json"
[ -f "$license_file" ] && {
    chflags -R 0 "$license_file"
    rm -f "$license_file"
}

if ! pgrep -x "prl_disp_service" &>/dev/null; then
    printf "${COLOR_INFO}[*] 正在启动 Parallels Service ...${NOCOLOR}\n"
    "$ParaHome/Contents/MacOS/Parallels Service" service_restart &>/dev/null
    for ((i = 0; i < 10; ++i)); do
        pgrep -x "prl_disp_service" &>/dev/null && break
        sleep 1
    done
    ! pgrep -x "prl_disp_service" &>/dev/null && printf "${COLOR_ERR}[x] 启动 Service 失败.${NOCOLOR}\n"
fi

"$ParaHome/Contents/MacOS/prlsrvctl" web-portal signout &>/dev/null
"$ParaHome/Contents/MacOS/prlsrvctl" set --cep off &>/dev/null
"$ParaHome/Contents/MacOS/prlsrvctl" set --allow-attach-screenshots off &>/dev/null

printf "${COLOR_SUCCESS}[*] 破解完成！${NOCOLOR}\n"
